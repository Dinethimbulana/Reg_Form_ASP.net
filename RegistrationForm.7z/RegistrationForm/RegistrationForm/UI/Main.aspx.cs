﻿using RegistrationForm.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using RegistrationForm.UI;

namespace RegistrationForm
{
    public partial class Main : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnReg_Click(object sender, EventArgs e)
        {
            if (txtbxConfirmPass.Text.Equals(txtbxPassword.Text))
            {
                var detail = new detailsDomain();
                var services = new Services();

                detail.FName = txtbxFname.Text;
                detail.LName = txtbxLname.Text;
                detail.Email = txtbxEmail.Text;
                detail.Gender = drdlGender.SelectedValue;
                detail.Address = txtbxAddress.Text;
                detail.PNo = txtbxPhoneNo.Text;
                detail.Password = txtbxPassword.Text;

                try
                {
                    services.Insert(detail);
                }
                catch (Exception ex)
                {
                    //lblReg.Text = ex;
                }
            }
            else 
            {
                lblReg.Text = "Password Error";
            }
        }
    }
}