﻿using RegistrationForm.Data;
using RegistrationForm.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RegistrationForm.UI
{
    class Services
    {
        private readonly DetailsData data = new DetailsData();

        public void Insert(detailsDomain datas)
        {
            data.Insert(datas);
        }
    }
}
